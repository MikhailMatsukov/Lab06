package kit.mdk0103.matsukov.lab06;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText txt_key;
    EditText txt_value;

    DB mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_key = findViewById(R.id.key);
        txt_value = findViewById(R.id.value);

        mydb = new DB (this, "mybase.db", null, 1);
    }

    //кнопка записи
    public void onInsert(View view) {
        String key  = txt_key.getText().toString();
        String value = txt_value.getText().toString();
        mydb.do_insert(key, value);
    }

    //кнопка обновления
    public void onUpdate (View view) {
        String key = txt_key.getText().toString();
        String value_upd = mydb.do_select(key);
        String value = txt_value.getText().toString();
        if (value_upd.equalsIgnoreCase(value)){
            txt_value.setText("Вы вписали одно и то же значение");
        }
        else {
            mydb.do_update(key, value);
        }
    }

    //кнопка выборки
    public void onSelect (View view) {
        String key =  txt_key.getText().toString();
        String value = mydb.do_select(key);
        txt_value.setText(value);
    }

    //кнопка удаления
    public void onDelete (View view) {
        String key = txt_key.getText().toString();
        String value_check = mydb.do_select(key);
        if (value_check == "(!) not found" || txt_value.getText().toString() == "Ключ был успешно удален") {
            txt_value.setText("У данного ключа нет значения");
        }

        else if (txt_value.getText().toString() != "Ключ был успешно удален"){
            String value = mydb.do_delete(key);
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Удалить?");
            builder.setMessage("Вы действительно хотите удалить данную запись?")
                    .setCancelable(true)
                    .setPositiveButton("Да", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            txt_value.setText(value);
                        }
                    })
                    .setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
    }

}